/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabajo2_5nov;

import java.util.Scanner;

/**
 *
 * @author Carmen
 */
public class Trabajo2_5nov {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        int dia = 0;

   while (dia!=8){
            System.out.println("Ingrese de que dia de la semana desea obtener informacion\n"
                    + "1. Lunes\n"
                    + "2. Martes\n"
                    + "3. Miercoles\n"
                    + "4. Jueves\n"
                    + "5. Viernes\n"
                    + "6. Sabado\n"
                    + "7. Domingo\n"
                    + "8. Salir");
            dia = entrada.nextInt();
            switch (dia) {
                case 1:
                    System.out.println("Es día laboral 👷‍");
                    break;
                case 2:
                    System.out.println("Es dia laboral 👷");
                    break;
                case 3:
                    System.out.println("Es dia laboral 👷");
                    break;
                case 4:
                    System.out.println("Es día laboral 👷‍");
                    break;
                case 5:
                    System.out.println("Es dia laboral 👷");
                    break;
                case 6:
                    System.out.println("NO es dia laboral 🎊");
                    break;
                case 7:
                    System.out.println("NO es dia laboral 🎊");
                    break;
                case 8:
                    System.out.println("Gracias por usar la aplicación!");
                    break;
            }
            }
        }
    }


